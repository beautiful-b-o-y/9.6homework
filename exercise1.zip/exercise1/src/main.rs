extern crate std;

use std::collections::HashMap;

#[macro_export]
macro_rules! hash_map {
    ($($key:expr=>$value:expr);*) => {
        {
            let mut temp_hash = HashMap::new();
            $(
                temp_hash.insert($key,$value);
            )*
            temp_hash
        }
    };
}

fn main(){
    let m = hash_map!{
        "Name" => "Tom";
        "Age" => "18";
        "Sex" => "male"
    };
    println!("{:#?}",m);
}
