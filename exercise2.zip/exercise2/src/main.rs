use std::ops::Deref;

#[derive(Debug)]
struct MyRc<T>
where T:Copy+Default,
{
    content:T,
    count:u32,
}

impl<T> MyRc<T> 
where T:Copy+Default,
{
    fn new(x: T) -> MyRc<T> {
        MyRc { content: x, count: 1 }
    }

    fn strong_count(&self) -> u32{
        self.count
    }

    fn clone(x:&mut MyRc<T>) -> MyRc<T>{
        x.count += 1;
        MyRc { content: x.content, count: x.count }
    }
}

impl<T> Deref for MyRc<T> 
where T:Copy+Default,
{
    type Target = T;

    fn deref(&self) -> &T {
        &self.content
    }
}

impl<T> Drop for MyRc<T> 
where T:Copy+Default,
{
    fn drop(&mut self) {
        if self.count == 1{
            self.content = T::default();
        }else{
            (*self).count -= 1;
        }
        
    }
}

fn main() {
    let mut five = MyRc::new(5);
    let five1 = MyRc::clone(&mut five);
    //实现自动解引用
    println!("five1={:#?}",five1);
    //实现计数功能
    println!("count = {}",MyRc::strong_count(&five));
}