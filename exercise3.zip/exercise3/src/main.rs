use std::cell::RefCell;

#[derive(Debug)]
struct  MyStack<T>{
    stack:RefCell<Vec<T>>,
}

impl <T> MyStack<T> {
    fn new() -> MyStack<T>{
        MyStack { stack: RefCell::new(Vec::new()), }
    }

    fn push(&self,value:T){
        self.stack.borrow_mut().push(value);
    }

    fn pop(&self) -> Option<T>{
        self.stack.borrow_mut().pop()
    }
}

fn main(){
    let stack = MyStack::new();
    stack.push(1);
    stack.push(2);
    stack.push(3);

    println!("pop:{:?}",stack.pop());
    println!("pop:{:?}",stack.pop());

    stack.push(4);
    stack.push(5);

    println!("pop:{:?}",stack.pop());
    println!("pop:{:?}",stack.pop());
    println!("pop:{:?}",stack.pop());
    println!("pop:{:?}",stack.pop());
}

#[test]
fn my_stack_test(){
    let stack = MyStack::new();
    stack.push(1);
    stack.push(2);
    stack.push(3);

    assert_eq!(stack.pop(),Some(3));
    assert_eq!(stack.pop(),Some(2));

    stack.push(4);
    stack.push(5);

    assert_eq!(stack.pop(),Some(5));
    assert_eq!(stack.pop(),Some(4));
    assert_eq!(stack.pop(),Some(1));
    assert_eq!(stack.pop(),None);
}